package gachon.mpclass.seterm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class G {
    public static HashMap<String,Object> hashMap = new HashMap<>();
    public static String imgUrl;
    public static String fileName;
    public static List<String> keyList = new ArrayList<String>();
}
